mod debian/z_graphql.ini
