#ifndef PHP_GRAPHQL_H
#define PHP_GRAPHQL_H

#define GRAPHQL_VERSION NO_VERSION_YET

PHP_MINIT_FUNCTION(graphql);

PHP_METHOD(Parser, parse);

#endif
